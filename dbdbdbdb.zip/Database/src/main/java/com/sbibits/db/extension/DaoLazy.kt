package com.sbibits.db.extension

import com.sbibits.db.DBManger
import com.sbibits.db.dao.BaseDao
import com.sbibits.db.dao.DaoCache
import com.sbibits.db.entity.BaseEntity
import kotlin.reflect.KClass

inline fun <reified T : BaseEntity> instanceDao(clazz: KClass<T>): BaseDao<T> {
    return DaoCache.get(DBManger.DB_TYPE, clazz)
}