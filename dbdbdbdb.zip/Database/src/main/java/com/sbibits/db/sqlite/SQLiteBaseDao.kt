package com.sbibits.db.sqlite

import com.sbibits.db.dao.BaseDao
import kotlin.reflect.KClass

class SQLiteBaseDao<T : SQLiteEntity>(clazz: KClass<T>) :
    BaseDao<T> by SQLiteImpl<T>(clazz)