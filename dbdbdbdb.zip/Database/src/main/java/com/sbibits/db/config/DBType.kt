package com.sbibits.db.config

enum class DBType {
    SQLite, Realm
}