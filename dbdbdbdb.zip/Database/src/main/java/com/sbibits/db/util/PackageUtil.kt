package com.sbibits.db.util

import android.content.Context
import android.content.pm.PackageManager
import dalvik.system.DexFile
import dalvik.system.PathClassLoader
import com.sbibits.db.DBManger
import com.sbibits.db.annotations.Entity
import com.sbibits.db.config.DBConfig
import com.sbibits.db.entity.BaseEntity
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList
import kotlin.reflect.KClass


object PackageUtil {

    /**
     * 扫描获得所有标注注解clazz的java Class
     *
     * @param context         context
     * @param annotationClass 注解class
     * @param applicationId   applicationId
     * @param packageNameList 需要扫描的package
     * @return
     */
    fun scanAllClass(
        context: Context,
        annotationClass: Class<out Annotation>,
        applicationId: String,
        vararg packageNameList: String
    ): List<Class<*>>? {
        try {
            val applicationInfo = context.packageManager.getApplicationInfo(applicationId, 0)
            val apkName = applicationInfo.sourceDir
            val dexFile = DexFile(apkName)
            val classLoader = PathClassLoader(apkName, Thread.currentThread().contextClassLoader)
            val classList: MutableList<Class<*>> = ArrayList()
            val entries: Enumeration<String> = dexFile.entries()
            while (entries.hasMoreElements()) {
                val entry: String = entries.nextElement()
                if (isNeedClass(entry, *packageNameList)) {
                    val entryClass = classLoader.loadClass(entry)
                    if (entryClass.isAnnotationPresent(annotationClass)) {
                        classList.add(entryClass)
                    }
                }
            }
            return classList
        } catch (e: PackageManager.NameNotFoundException) {
            DBManger.log(e.message ?: "")
        } catch (e: IOException) {
            DBManger.log(e.message ?: "")
        } catch (e: ClassNotFoundException) {
            DBManger.log(e.message ?: "")
        }
        return null
    }

    private fun isNeedClass(entry: String, vararg packageNameList: String): Boolean {
        for (packageName in packageNameList) {
            if (entry.startsWith(packageName)) {
                return true
            }
        }
        return false
    }
}