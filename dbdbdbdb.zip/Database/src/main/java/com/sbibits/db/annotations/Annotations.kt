package com.sbibits.db.annotations

/**
 * the normal column, usually used by the field that added in new version
 */
@Target(AnnotationTarget.FIELD)
annotation class Column(
    /**
     * version that this field belong to
     */
    val version: Int = 0

)

/**
 * the column that don't relate to the table
 */
@Target(AnnotationTarget.FIELD)
annotation class IgnoreColumn(

)

/**
 * the primary key field
 */
@Target(AnnotationTarget.FIELD)
annotation class Primary(

)

/**
 * the base entity class
 */
@Target(AnnotationTarget.CLASS)
annotation class Entity(

)