package com.sbibits.db.realm

import android.content.Context
import io.realm.*
import com.sbibits.db.annotations.Column
import com.sbibits.db.annotations.Primary
import com.sbibits.db.config.DBConfig
import com.sbibits.db.DBManger
import com.sbibits.db.extension.getSQLColumn
import java.util.concurrent.ConcurrentHashMap
import kotlin.reflect.full.createInstance
import kotlin.reflect.jvm.javaField

object RealmManager {

    private var THREAD_INSTANCES = ConcurrentHashMap<Long, Realm>()

    fun init(context: Context, realmModule: Any?, config: DBConfig) {
        Realm.init(context)
        val realmConfiguration: RealmConfiguration = RealmConfiguration.Builder()
            .name(config.name)
            .schemaVersion(config.version.toLong())
            .migration(MigrationHelper())
            .allowQueriesOnUiThread(true)
            .allowWritesOnUiThread(true)
            .modules(Realm.getDefaultModule(),realmModule)
            .build()
        Realm.setDefaultConfiguration(realmConfiguration)
        //do the migration when init
        var r: Realm? = null
        try {
            r = Realm.getDefaultInstance()
        } catch (e: Exception) {
            DBManger.log("RealmManager init failed ${e.message}")
        } finally {
            r?.close()
        }
    }

    fun getInstance(): Realm {
        val threadId = Thread.currentThread().id
        return if (THREAD_INSTANCES.containsKey(threadId)) {
            var instance = THREAD_INSTANCES[threadId]
            if (null == instance || instance.isClosed) {
                instance = Realm.getDefaultInstance()
                THREAD_INSTANCES[threadId] = instance
            }
            instance ?: Realm.getDefaultInstance()
        } else {
            val instance = Realm.getDefaultInstance()
            THREAD_INSTANCES[threadId] = instance
            instance
        }
    }

    fun closeRealm() {
        val threadId = Thread.currentThread().id
        if (THREAD_INSTANCES.containsKey(threadId)) {
            val instance = THREAD_INSTANCES[threadId]
            if (instance != null && !instance.isClosed) {
                instance.close()
                THREAD_INSTANCES.remove(threadId)
            }
        }
    }

    /**
     * データベースのアップグレード
     */
    class MigrationHelper : RealmMigration {

        override fun migrate(realm: DynamicRealm, oldVersion: Long, newVersion: Long) {
            upgrade(realm, oldVersion, newVersion)
        }

        fun upgrade(realm: DynamicRealm, oldVersion: Long, newVersion: Long) {
            val schema: RealmSchema = realm.schema
            for (it in DBManger.entityClass) {
                val realmEntity =
                    (it.createInstance() as? RealmEntity<*>)?.getRealmClass()?.createInstance() ?: continue
                //get the realm object name to do the migration
                val realmName = realmEntity::class.java.simpleName
                val targetSchema =
                    schema.get(realmName) ?: schema.create(realmName) ?: continue
                val target = it.getSQLColumn()
                target.forEachIndexed { index, kProperty1 ->
                    val field = kProperty1.javaField ?: return@forEachIndexed
                    var version = 0
                    if (field.isAnnotationPresent(Column::class.java)) {
                        version = field.getAnnotation(Column::class.java).version
                    }
                    //this origin version or new version column could force to do the update
                    if ((oldVersion == DBManger.DATABASE_ORIGIN_VERSION.toLong()
                                || version > oldVersion) && !targetSchema.hasField(field.name)) {
                        val isPrimary = field.isAnnotationPresent(Primary::class.java)
                        targetSchema.addField(
                            field.name,
                            field.type,
                            if (isPrimary) FieldAttribute.PRIMARY_KEY else null
                        )
                    }
                }
            }
        }
    }
}