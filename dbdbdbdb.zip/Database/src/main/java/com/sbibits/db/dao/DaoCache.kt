package com.sbibits.db.dao

import io.realm.RealmModel
import com.sbibits.db.config.DBType
import com.sbibits.db.entity.BaseEntity
import com.sbibits.db.extension.getTableName
import com.sbibits.db.realm.RealmBaseDao
import com.sbibits.db.realm.RealmEntity
import com.sbibits.db.sqlite.SQLiteEntity
import com.sbibits.db.sqlite.SQLiteImpl
import kotlin.reflect.KClass
import kotlin.reflect.full.createInstance

object DaoCache {

    private val cacheDao = hashMapOf<String, BaseDao<out BaseEntity>>()

    /**
     * get dao by cache / create dao
     */
    fun <T : BaseEntity> get(type: DBType, clazz: KClass<T>): BaseDao<T> {
        val key = type.name + "_" + clazz.getTableName()
        return cacheDao.getOrPut(key, {
            createDao(type, clazz)
        }) as BaseDao<T>
    }

    /**
     * create dao impl
     */
    private fun <T : BaseEntity> createDao(dbType: DBType, clazz: KClass<T>): BaseDao<T> {
        val entity = clazz.createInstance()
        if (entity is SQLiteEntity && dbType == DBType.SQLite) {
            return SQLiteImpl(entity::class as KClass<SQLiteEntity>) as BaseDao<T>
        }
        if (entity is RealmEntity<*> && dbType == DBType.Realm) {
            return RealmBaseDao(
                entity::class as KClass<RealmEntity<RealmModel>>,
                entity.getRealmClass() as KClass<RealmModel>
            ) as BaseDao<T>
        }
        throw Exception("no implementation!")
    }
}