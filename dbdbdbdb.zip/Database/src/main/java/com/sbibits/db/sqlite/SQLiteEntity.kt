package com.sbibits.db.sqlite

import android.provider.BaseColumns
import com.sbibits.db.entity.BaseEntity

interface SQLiteEntity : BaseColumns, BaseEntity {

}