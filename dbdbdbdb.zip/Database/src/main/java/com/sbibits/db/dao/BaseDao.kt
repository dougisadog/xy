package com.sbibits.db.dao

import com.sbibits.db.entity.BaseEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

interface BaseDao<T : BaseEntity> {

    /**
     * @param id primary key
     */
    fun find(id: Any): T?

    /**
     * it may cause Exception when run in UI Thread,usually use async with it
     * @param entity the target entity to save
     */
    fun save(entity: T): Boolean

    /**
     * it may cause Exception when run in UI Thread,usually use async with it
     */
    fun save(entities: Collection<T>)

    /**
     * it may cause Exception when run in UI Thread,usually use async with it
     * @param id primary key
     */
    fun delete(id: Any): Boolean

    fun deleteAll()

    /**
     * @param entity the search condition, effect by its properties value
     * (if the property got null value,just omit the condition, if all properties got null value , search all the table)
     * @return list match the condition
     */
    fun query(entity: T?): MutableList<T>

    /**
     * Transaction block
     * @param block the async update task return if transaction success
     */
    fun runTransaction(block: () -> Boolean)

    /**
     * async update task（save，delete...etc）
     * @param block the async update task
     * @param after the come on task just after block
     */
    fun async(block: () -> Unit, after: (() -> Unit)? = null) {
        GlobalScope.launch(Dispatchers.IO) {
            block()
            //invoke the after in Main Thread as default
            withContext(Dispatchers.Main) {
                after?.invoke()
            }
        }
    }

}