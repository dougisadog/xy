package com.sbibits.db.config.classloader

import com.sbibits.db.entity.BaseEntity
import kotlin.reflect.KClass

interface BaseEntityClassLoader {
    fun <T : KClass<out BaseEntity>> load(): MutableList<T>
}