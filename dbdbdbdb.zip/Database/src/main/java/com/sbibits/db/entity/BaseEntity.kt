package com.sbibits.db.entity

import com.sbibits.db.extension.getPrimary
import com.sbibits.db.extension.getTableName

interface BaseEntity {

    /**
     * @return the table name
     */
    fun getTableName(): String {
        return this::class.getTableName()
    }

    /**
     * @return the primary id
     */
    fun getPrimaryId(): Any? {
        return this::class.getPrimary().getter.call(this)
    }

}