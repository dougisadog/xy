package com.sbibits.db.realm

/**
 * @param module created by the project module which use Realm from this library
 */
class RealmConfig(val module: Any?)