package com.sbibits.db.realm

import com.sbibits.db.DBManger
import com.sbibits.db.dao.BaseDao
import com.sbibits.db.extension.getPrimary
import com.sbibits.db.extension.getSQLColumn
import com.sbibits.db.tryBlock
import io.realm.Realm
import io.realm.RealmModel
import kotlin.reflect.KClass
import kotlin.reflect.full.createInstance
import kotlin.reflect.jvm.javaField

/**
 * Realm DAO impl
 * @param T RealmEntity class
 * @param RE RealmModel class match the T
 */
class RealmImpl<T : RealmEntity<RE>, RE : RealmModel>(
    private val clazz: KClass<T>,
    private val realmClazz: KClass<RE>
) : BaseDao<T> {
    override fun find(id: Any): T? {
        val mRealm = RealmManager.getInstance()
        val primaryP = clazz.getPrimary()
        val helper = RealmTypeHelper<RE>(primaryP)
        val dbData = helper.equalTo(mRealm.where(realmClazz.java), id)?.findFirst() ?: return null
        val source = clazz.createInstance()
        source.initByRealmObject(dbData)
        return source
    }

    override fun save(entity: T): Boolean {
        // the primary key can't be null when do saving
        entity.getPrimaryId() ?: return false
        val mRealm = RealmManager.getInstance()
        return tryBlock("Realm save failed") {
            mRealm.runTransaction {
                it.copyToRealmOrUpdate(entity.generateRealmObject())
                true
            }
            true
        } ?: false
    }

    override fun save(entities: Collection<T>) {
        val source = entities.filter {
            // the primary key can't be null when do saving
            null != it.getPrimaryId()
        }.map {
            it.generateRealmObject()
        }
        val mRealm = RealmManager.getInstance()
        tryBlock("Realm save failed") {
            mRealm.runTransaction {
                it.copyToRealmOrUpdate(source)
                true
            }
        }
    }

    override fun delete(id: Any): Boolean {
        val mRealm = RealmManager.getInstance()

        return tryBlock("Realm save failed") {
            val primaryP = clazz.getPrimary()
            val helper = RealmTypeHelper<RE>(primaryP)
            val target = helper.equalTo(mRealm.where(realmClazz.java), id)?.findAll()
            mRealm.runTransaction {
                target?.deleteAllFromRealm()
                true
            }
            true
        } ?: false

    }

    override fun deleteAll() {
        val mRealm = RealmManager.getInstance()
        tryBlock("Realm delete all failed") {
            mRealm.runTransaction {
                it.delete(realmClazz.java)
                true
            }
        }
    }

    override fun query(entity: T?): MutableList<T> {
        val mRealm = RealmManager.getInstance()
        val results = mutableListOf<T>()
        val columns = clazz.getSQLColumn()
        return tryBlock("Realm Query failed") {
            val searchQuery = mRealm.where(realmClazz.java)
            if (null != entity) {
                columns.forEachIndexed { index, c ->
                    val field = c.javaField ?: return@forEachIndexed
                    field.isAccessible = true
                    val value = field.get(entity) ?: return@forEachIndexed

                    val helper = RealmTypeHelper<RE>(c)
                    helper.equalTo(searchQuery, value)
                }
            }
            results.addAll(searchQuery.findAll().map {
                val resultEntity = clazz.createInstance()
                resultEntity.initByRealmObject(it)
                resultEntity
            })
            results
        } ?: results
    }

    private fun Realm.runTransaction(block: (Realm) -> Boolean) {
        val blockTask = {
            if (!block.invoke(this)) {
                DBManger.log("Realm transaction failed by result")
            }
        }
        if (isInTransaction) {
            blockTask.invoke()
        } else {
            executeTransaction {
                blockTask.invoke()
            }
        }
    }

    override fun runTransaction(block: () -> Boolean) {
        val mRealm = RealmManager.getInstance()
        tryBlock("Realm transaction failed by exception") {
            mRealm.runTransaction {
                block.invoke()
            }
        }
    }

    override fun async(block: () -> Unit, after: (() -> Unit)?) {
        val mRealm = RealmManager.getInstance()
        try {
            mRealm.executeTransactionAsync(Realm.Transaction {
                block()
            }, Realm.Transaction.OnSuccess {
                after?.invoke()
            }, Realm.Transaction.OnError {
                after?.invoke()
            })
        } catch (e: Exception) {
            e.printStackTrace()
            after?.invoke()
        }
    }


}