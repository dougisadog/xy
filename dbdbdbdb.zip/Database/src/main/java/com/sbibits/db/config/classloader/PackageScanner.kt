package com.sbibits.db.config.classloader

import android.content.Context
import com.sbibits.db.annotations.Entity
import com.sbibits.db.entity.BaseEntity
import com.sbibits.db.util.PackageUtil
import kotlin.reflect.KClass

class PackageScanner(
    val context: Context,
    val applicationId: String,
    val packageNameList: String
) : BaseEntityClassLoader {
    override fun <T : KClass<out BaseEntity>> load(): MutableList<T> {
        val classes = mutableListOf<T>()
        val targets = PackageUtil.scanAllClass(
            context,
            Entity::class.java,
            applicationId,
            packageNameList
        )
        targets?.forEach {
            (it.kotlin as? T)?.let {
                classes.add(it)
            }
        }
        return classes
    }
}