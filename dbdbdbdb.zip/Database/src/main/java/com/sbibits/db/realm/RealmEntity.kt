package com.sbibits.db.realm

import com.sbibits.db.annotations.IgnoreColumn
import com.sbibits.db.entity.BaseEntity
import io.realm.RealmModel
import kotlin.reflect.KClass
import kotlin.reflect.KMutableProperty1
import kotlin.reflect.full.createInstance
import kotlin.reflect.full.declaredMemberProperties
import kotlin.reflect.jvm.isAccessible
import kotlin.reflect.jvm.javaField

/**
 * RealmEntity class
 * @param RE RealmModel class match this class
 */
abstract class RealmEntity<RE : RealmModel> : BaseEntity {

    /**
     * init this by the matched RealmModel
     */
    open fun initByRealmObject(source: RE) {
        val sourceProps = getRealmClass().createInstance()::class.declaredMemberProperties
        val sourceMaps = hashMapOf<String, Any?>()
        sourceProps.forEach {
            it.isAccessible = true
            sourceMaps.put(it.name, it.getter.call(source))
        }
        val props = this::class.declaredMemberProperties
        props.forEach {
            val currentPropName = it.name
            val prop = it as KMutableProperty1<RealmEntity<RE>, Any?>
            if (prop.javaField?.isAnnotationPresent(IgnoreColumn::class.java) != true) {
                if (sourceMaps.containsKey(currentPropName)) {
                    prop.set(this, sourceMaps[currentPropName])
                }
            }
        }
    }

    /**
     * create the matched RealmModel by this
     */
    open fun generateRealmObject(): RE {
        val result = getRealmClass().createInstance()
        val sourceProps = this::class.declaredMemberProperties
        val sourceMaps = hashMapOf<String, Any?>()
        sourceProps.forEach {
            it.isAccessible = true
            if (it.javaField?.isAnnotationPresent(IgnoreColumn::class.java) != true) {
                sourceMaps.put(it.name, it.getter.call(this))
            }
        }

        val props = getRealmClass().declaredMemberProperties
        props.forEach {
            val currentPropName = it.name
            val prop = it as KMutableProperty1<RE, Any?>
            if (sourceMaps.containsKey(currentPropName)) {
                prop.set(result, sourceMaps[currentPropName])
            }
        }
        return result
    }

    /**
     * get the RealmModel KClass
     */
    abstract fun getRealmClass(): KClass<RE>

}