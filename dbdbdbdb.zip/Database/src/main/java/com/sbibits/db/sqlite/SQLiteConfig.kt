package com.sbibits.db.sqlite

class SQLiteConfig